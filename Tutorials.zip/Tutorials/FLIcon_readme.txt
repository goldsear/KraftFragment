FLIcon - a quick-n-dirty tool to generate NN_ICONs

#1 ~Kazinsal @2014/6/20 5:24


Hey folks,

Couldn’t find a tool like this, so I wrote my own. It’s fairly straightforward - drag and drop an uncompressed power-of-two TGA onto it (or invoke it from the commandline as flicon icon.tga) and it’ll create a uniquely-identified NN_ICON 3db out of it for use for commodities, equipment, ships, etc.

It only does one TGA per invocation so if you need to convert a whole bunch of TGAs to NN_ICONs I recommend writing an equally quick and dirty batch file to do it for you 😉

No need to credit the tool in your mod if you don’t want to, as long as you don’t remove the Exporter Version nodes from the resulting 3db files.

–Troy


#2 ~StarTrader @2014/6/22 2:12
Nice work Kazinsal.


#3 ~Xarian_Prime @2014/6/22 11:35
very nice 🙂 thanks